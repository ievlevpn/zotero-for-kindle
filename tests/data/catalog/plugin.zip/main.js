// src/main.ts
console.log(`${zk.plugin.id} ${zk.plugin.version} loaded`);
zk.on("bookFinished", ({ item, attachment }) => {
  const authors = item.creators.map((c) => c.last ?? c.name).join(", ");
  console.log(`Finished "${item.title}" by ${authors || "unknown"} (${attachment.contentType})`);
});
